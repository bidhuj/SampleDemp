package steps;

import com.fasterxml.jackson.core.JsonProcessingException;
import constants.GlobalVars;
import utilities.DeSerialization;
import servicehelpers.Get;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import utilities.Serialization;
import settergetter.ThreadSafety;
import static io.restassured.RestAssured.given;

import static org.hamcrest.Matchers.*;

public class login {

	@Given("Hit the Api And get the results")
	public void hit_the_api_and_get_the_results() {
		RestAssured.baseURI="https://reqres.in/";
	          String requestBody = "{\n" +
	                  "  \"name\": \"morpheus\",\n" +
	                  "  \"job\": \"leader\"\n" +
	                  "}";

	        Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("/api/users?page=2")
	                .then()
	                .extract().response();
//	        response = performPostMethod(Hooks.baseUrl, EndPoints.CASES, buildAPayload.generateStringFromResource("src\\test\\resources\\testdata\\TC1_case1_1Life.json"));
	        System.out.println("Before Response" +response);
          
	}
}
