package e2e;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.testng.TestNGCitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;
import com.consol.citrus.integration.Demo.CommonClass;
import com.consol.citrus.integration.Demo.Constants;
import com.consol.citrus.integration.Demo.DataUtil;
import com.consol.citrus.integration.Demo.ExtentManager;
import com.consol.citrus.integration.Demo.Xls_Reader;
import com.consol.citrus.message.MessageType;
import com.github.javafaker.Faker;
import com.github.javafaker.service.FakeValuesService;
import com.github.javafaker.service.RandomService;
import com.jayway.jsonpath.JsonPath;
import com.relevantcodes.extentreports.ExtentTest;

import jdk.nashorn.internal.runtime.Context;

public class Asapp_Tc2 extends TestNGCitrusTestDesigner {

	@Autowired(required = true)
	public static com.relevantcodes.extentreports.ExtentReports extent = ExtentManager.getInstance();
	public static ExtentTest test;
	public Xls_Reader xls = new Xls_Reader(Constants.DATA_XLS_PATH);
	String testCaseName = "Asapp_Tc2"; // TestCase Name has to entered

	/*
	 * Login Directly with the Registered user Add the product to the cart Remove
	 * the product from the cart
	 */
	@Test(dataProvider = "getData")
	@CitrusTest
	public void Login_AddtoCart_RemoveFromCart(Hashtable<String, String> data) {

		variable("UserName", CommonClass.UserName);
		variable("Pwd", CommonClass.Pwd);
		
		//Login with the registered user
		http().client(CommonClass.Asapp_API_URL).send().post("users/login")
				.contentType("application/json")
				.payload("{\"username\":\"${UserName}\",\"password\":\"${Pwd}\"}");
		http().client(CommonClass.Asapp_API_URL).receive().response(HttpStatus.OK).messageType(MessageType.JSON);

		
		//List out all the products
		http().client(CommonClass.Asapp_API_URL).send().get("${UserName}/products")
				.contentType("application/json");
		http().client(CommonClass.Asapp_API_URL).receive().response(HttpStatus.OK).messageType(MessageType.JSON).extractFromPayload("$[0].product_name", "product_name");;

		//List out all the products
		http().client(CommonClass.Asapp_API_URL).send().get("${UserName}/products/${product_name}")
				.contentType("application/json");
		http().client(CommonClass.Asapp_API_URL).receive().response(HttpStatus.OK).messageType(MessageType.JSON);
		
		//Add product to cart
		http().client(CommonClass.Asapp_API_URL).send().post("${UserName}/products/${product_name}/add")
				.contentType("application/json")
				.payload("{\"quantity\":2}");
		http().client(CommonClass.Asapp_API_URL).receive().response(HttpStatus.OK).messageType(MessageType.JSON);
		
		//Remove the product from the Basket
		http().client(CommonClass.Asapp_API_URL).send().post("${UserName}/products/cart/${product_name}/remove")
				.contentType("application/json");
		http().client(CommonClass.Asapp_API_URL).receive().response(HttpStatus.OK).messageType(MessageType.JSON);
		
	}
	


	@AfterMethod
	public void quit() {
		if (extent != null) {
			// extent.endTest(test);
			extent.flush();
		}

	}

	@DataProvider
	public Object[][] getData() {
		return DataUtil.getData(xls, testCaseName);
	}
}
