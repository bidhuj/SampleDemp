package com.consol.citrus.integration.Demo;

import java.util.Map;

import com.consol.citrus.TestCase;  
import com.consol.citrus.report.AbstractTestListener;
import com.consol.citrus.report.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReporter extends AbstractTestListener implements TestReporter  {

	  private static ExtentReports extent=ExtentManager.getInstance();	  
	  private static ExtentTest ET;



    @Override
    public void onTestSuccess(TestCase test) {
   
        
    	ET=extent.startTest(test.getName()); 
    	ET.log(LogStatus.PASS, "Pass");
       
    }

    @Override
    public void onTestSkipped(TestCase test) {
    	ET=extent.startTest(test.getName());
     	ET.log(LogStatus.SKIP, "Test case Skipped");  
    	
    }

    @Override	
    public void onTestFailure(TestCase test, Throwable cause) {
    	ET=extent.startTest(test.getName());
    	ET.log(LogStatus.FAIL, "FAIL",cause.toString());
    	
    	
    	
    }

	@Override
	public void clearTestResults() {
		// TODO Auto-generated method stub
		
	}
    

    @Override
    public void generateTestResults() {
    //	extent.endTest(ET);
      
    }

    
    public void afterPropertiesSet() throws Exception {
    	//extent.flush();	
       
    }

}
  
