package com.consol.citrus.integration.Demo;

import java.util.Locale;

import org.testng.annotations.BeforeSuite;

import com.github.javafaker.service.FakeValuesService;
import com.github.javafaker.service.RandomService;






public class CommonClass {

	static FakeValuesService fakeValuesService = new FakeValuesService(new Locale("en-GB"), new RandomService());
	public static String UserName = fakeValuesService.bothify("????????");
	public static String Pwd = fakeValuesService.bothify("t?????");
	static String Ip = System.getenv("exthost");
	public static String Asapp_API_URL = "http://"+"api"+":5000/";
	
	@BeforeSuite
	public void rep() {
		System.out.println("---UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU---->" +Asapp_API_URL);
	}
	


}
