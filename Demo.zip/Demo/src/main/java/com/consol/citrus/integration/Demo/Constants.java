package com.consol.citrus.integration.Demo;

import java.util.Hashtable;

public class Constants {
	
	public static final String REPORTS_PATH = System.getProperty("user.dir")+"/Report/";
	public static final String DATA_XLS_PATH = System.getProperty("user.dir")+"/data/Data.xlsx";
	public static final String TESTDATA_SHEET = "TestData";
	public static final String TESTCASES_SHEET = "TestCases";
    public static final String Authorization = "";
	public static final String RUNMODE_COL = "Runmode";
	public static final String PARAM_1 = "Param_1";
	public static final String PARAM_2 = "Param_2";
	
	public static final String JWT_Token = "JWT_Token";


	public static final String Fintso_USERNAME = "bidhu.bhusan@fintso.com";
	public static final String Fintso_Outlook = "Unisys123#";
	public static final String Fintso_PASSWORD = "Bhusan12#";
	
	public static final String Fintso_USERNAME_POC = "bidhu.bhusan@fintso.com";
	public static final String Fintso_PASSWORD_POC = "Bhusan12#";
	
	public static final String Fintso_USERNAME_OPSHead = "ghostopshead@gmail.com";
	public static final String Fintso_PASSWORD_OPSHead = "Bhusan12#";
	
	public static final String Fintso_USERNAME_Sales = "ghostsalesguy@gmail.com";
	public static final String Fintso_PASSWORD_Sales = "Bhusan12#";
	
	public static final String Fintso_USERNAME_opsExec = "ghostopsexec@gmail.com";
	public static final String Fintso_PASSWORD_opsExec = "Bhusan12#";
	
	public static final String Fintso_USERNAME_ServiceHead = "ghostservicehead@gmail.com";
	public static final String Fintso_PASSWORD_ServiceHead = "Bhusan12#";
	
	public static final String Fintso_USERNAME_ServiceExec = "ghostserviceexec@gmail.com";
	public static final String Fintso_PASSWORD_ServiceExec = "Bhusan12#";	
	
	public static final String Fintso_USERNAME_Assoc = "associateassociate3@gmail.com";
	public static final String Fintso_PASSWORD_Assoc = "Bhusan12#";		

	
	public static final String Fintso_UserName_Client_Create = "subscriber914914@gmail.com";
	public static final String Fintso_Pwd_Client_Create = "Fintso123";	
	
	
}
