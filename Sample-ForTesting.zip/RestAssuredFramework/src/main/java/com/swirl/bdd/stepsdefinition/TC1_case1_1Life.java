package com.swirl.bdd.stepsdefinition;

import com.swirl.base.EndPoints;
import com.swirl.base.Hooks;
import com.swirl.base.ObjectManager;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import static com.swirl.utility.SpecBuilder.printResponseLogInReport;
import static io.restassured.RestAssured.given;


public class TC1_case1_1Life extends ObjectManager {

    Response response;
    @Given("User hits post Api with the supplied data")
    public void user_hits_post_api_with_the_supplied_data() throws IOException {
        System.out.println("Hooks.baseUrl==>" +Hooks.baseUrl);
        RestAssured.baseURI="https://reqres.in/";
          String requestBody = "{\n" +
                  "  \"name\": \"morpheus\",\n" +
                  "  \"job\": \"leader\"\n" +
                  "}";

        Response response = given().relaxedHTTPSValidation()
                .contentType(ContentType.JSON)
                .when()
                .get("/api/users?page=2")
                .then()
                .extract().response();
//        response = performPostMethod(Hooks.baseUrl, EndPoints.CASES, buildAPayload.generateStringFromResource("src\\test\\resources\\testdata\\TC1_case1_1Life.json"));
        System.out.println("Before Response");
      //  printResponseLogInReport(response);
    }
 /*   @When("Enter all the case data")
    public void enter_all_the_case_data() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @Then("Verify status code as {int}")
    public void verify_status_code_as(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @Then("Verify the status Message")
    public void verify_the_status_message() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }*/
}
