package com.swirl.report;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.presentation.PresentationMode;
import net.masterthought.cucumber.sorting.SortingMethod;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CucumberExtentReports{

    public CucumberExtentReports() {

    }

    public static void cucumberReports(String outputDir) {
//        Properties prop = init_properties(IConstants.CUCUMBER_CONFIG_PATH);
        File reportOutputDirectory = new File(outputDir);
        List<String> jsonFiles = new ArrayList<>();
        jsonFiles.add("target/MyReports/cucumber.json");

        String buildNumber = "";
        String projectName = "";
        Configuration configuration = new Configuration(reportOutputDirectory, projectName);
        configuration.setBuildNumber(buildNumber);

//        configuration.addClassifications("Browser", ((RemoteWebDriver)driver).getCapabilities().getBrowserName());
//        configuration.addClassifications("Browser Version",((RemoteWebDriver)driver).getCapabilities().getBrowserVersion() );
//        configuration.addClassifications("Branch", prop.getProperty("Branch"));
        configuration.setSortingMethod(SortingMethod.NATURAL);
        configuration.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
        configuration.addPresentationModes(PresentationMode.PARALLEL_TESTING);

//        configuration.setQualifier("sample", "Chrome 80, mobile");

        configuration.setTrendsStatsFile(new File("target/test-classes/demo-trends.json"));

//        configuration.addCustomCssFiles(Collections.singletonList("src/test/resources/css/stackoverflow-light.min.css"));
//        configuration.addCustomJsFiles(Arrays.asList("src/test/resources/js/enable-highlighting.js", "src/test/resources/js/highlight.min.js"));

        ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
        reportBuilder.generateReports();
    }
}
