package com.swirl.base;



import io.cucumber.java.*;

import com.swirl.utility.ReadProperties;

import java.util.Properties;

public class Hooks{

    public static Scenario scenario;
//    public static JSONObject testData;
    public static String baseUrl;

    @Before
    public void setUp(Scenario scenario) {
        Hooks.scenario = scenario;
        ReadProperties properties = new ReadProperties();
        Properties prop = properties.initProperties(Constants.TEST_CONFIG_PATH);
        baseUrl = prop.getProperty("BaserUrl");
    }

   @After
    public void tearDown(Scenario scenario) {

    }
}
