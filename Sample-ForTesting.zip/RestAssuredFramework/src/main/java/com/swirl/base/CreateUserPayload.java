package com.swirl.base;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;


@Value
//@Data
//@Getter
//@Setter
@Jacksonized
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateUserPayload {

    @JsonProperty("name")
    String name;
    @JsonProperty("job")
    String job;

}
