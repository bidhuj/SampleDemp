package com.swirl.base;



import java.util.Properties;

import com.swirl.utility.ReadProperties;

public class Constants {

    private Constants() {

    }

    static ReadProperties properties = new ReadProperties();
    private static final Properties prop = properties.initProperties("./src/test/resources/projectConfig.properties");

    public static final String CUCUMBER_CONFIG_PATH = prop.getProperty("CucumberConfigPath");
    public static final String EMAIL_CONFIG_PATH = prop.getProperty("EmailConfigPath");
    public static final String TEST_CONFIG_PATH = prop.getProperty("TestConfigPath");
    public static final String TEST_DATA_FILE_PATH = prop.getProperty("TestDataFile");
    public static final String EXTENT_CONFIG_PATH = "src/test/resources/extentReportConfig.properties";
    public static final String COOKIES = "Cookie: AppServiceAuthSession=KJM30w8/YRPndyFL+ZuHahPLf9Zwvu/nDrEpU3keM0H3on+1vGq2hgN/MemNcaktap3Edrhub5ZGKqm/ZJ7nc28C35JM35swP479Feu0BLov0afTxBqIXkL+Tgr9bvvWLIHUgZjlygf4oLLVdFYY2SSA5kWTLAUBrnkwb72zvj7KXqf4iw2LQbmIZzBZH/W6pobWx8UweEigVh6DY6E4XBRpJy2+IpwIC+owRVYV22Eh83od52wzo1WhGmmlkbxVyL0PjbfoEivo8OPrJT7BWMr/bp35Ky1ex7+BMtjPeh9VKMdBgOs5DpYb3BgV3Rqp2O7cAi/GM2hmQqPEADoCkl66vK73ToSm1c3a2N2/CCPbKAEh7+cYbnaWqlV/8VWLSME3YJkHZcMouRt/+oWBvjgWoBDM4nd/tKcP51uOcocZl6MJ3/wkYCrAnow9TzYWf4SANGoT/ezLMWHSNgw/MGZswQ/JGdJBDXor32SmHOwEGnwG/MT7EtideGAzzy7N5AGiL0WrtG19H9CYmyCwrLmp/KE0+CTi7JwuAoQj1Q05WFMdqZc4g34eKMyn7KeO456wG5wFQSMZoyFH6y3ElJnnKEU8HZMGM2VCjC/PgYcZkX9TKfufwtxtcpfDSuqUm1uAyVdmX4tQvlUx/9mVJ1w2Q/+BV9fZd6DDfYcdSmArhX2MHmv52ywIOQ2HVucaDqcMfCaHkj81vtYbAZuO+bsHFG4qqPD0B+OFv3oG58hING8dPvd2daqioGUo2eAyYtap7kVFmPGZVcq2bqorj1bt+fNsHApSlru228svZBFJeLKwojhLH88jdNeEAb4mWvCp92+1+/6txPahYpR0I1cghpJTtq4Hf/gQhAhpqV6bIhUTMNuARpF+FL99QP740Y/EVpw41vBd9x3bJ3a2otzIhw1yk5q9tTuCfW9g53aWXJSGwzqhC2muRj+YzyIREzqJZ52oTCKeMYRTUAP77JKiRim2nddWTrT4LKKwze7/wr+sCMUs2Qq2ego5TWR3mqscNYj+KTvO3Qh1rREj6MPnwbNzVop4pVjb9uKdBqd58fbmWXFJG9rKVCyJA+Ad3d8UMSpcuijefvBxVSPSi7pdtaM0IkHU0z8Lr1zTXWZkUmxUKMDclt8J8vDTjLpC14X+vNZjp4fDPBULoYC3JQ==";

}

