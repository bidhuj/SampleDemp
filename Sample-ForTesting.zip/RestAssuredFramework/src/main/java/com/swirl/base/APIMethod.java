package com.swirl.base;


import com.swirl.utility.SpecBuilder;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.collections4.BagUtils;
import org.apache.http.params.CoreConnectionPNames;

import java.util.Map;

import static com.swirl.utility.SpecBuilder.printRequestLogInReport;
import static com.swirl.utility.SpecBuilder.printRequestLogInReportWithPayload;
import static io.restassured.RestAssured.given;


public class APIMethod {


    public Response performPostMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers) {

        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload, headers));
        Response response = requestSpecification.when().post(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPostMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers, Map<String, Object> query) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload, headers, query));
        Response response = requestSpecification.when().post(endpoint);
      //  printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPostMethod(String baseUrl, String endpoint, Object payload) {
       /* RestAssuredConfig config = RestAssured.config()
                .httpClient(HttpClientConfig.httpClientConfig()
                        .setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 100000)
                        .setParam(CoreConnectionPNames.SO_TIMEOUT, 10000000));*/
        RequestSpecification requestSpecification = given().contentType("application/json").spec(SpecBuilder.getRequestSpecification(baseUrl, payload));
        Response response = requestSpecification.when().post(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performGetMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload, headers));
        Response response = requestSpecification.when().get(endpoint);
      //  printRequestLogInReportWithPayload(requestSpecification);

        return response;
    }

    public Response performGetMethod(String baseUrl, String endpoint, Object payload, Map<String,
            String> headers, Map<String, Object> queryParameters) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload,
                headers, queryParameters));
        Response response = requestSpecification.when().get(endpoint);
       // printRequestLogInReportWithPayload(requestSpecification);

        return response;
    }

    public Response performGetMethod(String baseUrl, String endpoint, Map<String, Object> queryParameters) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl,
                queryParameters));
        Response response = requestSpecification.when().get(endpoint);
      //  printRequestLogInReport(requestSpecification);

        return response;
    }

    public Response performGetMethod(String baseUrl, String endpoint, Map<String,
            String> headers, Map<String, String> queryParameters) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl,
                headers, queryParameters));
        Response response = requestSpecification.when().get(endpoint);
      //  printRequestLogInReport(requestSpecification);

        return response;
    }

    public Response performPutMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload, headers));
        Response response = requestSpecification.when().put(endpoint);
      //  printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPutMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers, Map<String, Object> query) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload, headers, query));
        Response response = requestSpecification.when().put(endpoint);
      //  printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPutMethod(String baseUrl, String endpoint, Object payload) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload));
        Response response = requestSpecification.when().put(endpoint);
      //  printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performDeleteMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload, headers));
        Response response = requestSpecification.when().delete(endpoint);
      //  printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performDeleteMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers, Map<String, Object> query) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload, headers, query));
        Response response = requestSpecification.when().delete(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performDeleteMethod(String baseUrl, String endpoint, Object payload) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecification(baseUrl, payload));
        Response response = requestSpecification.when().delete(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPostWithMultiPartMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecificationWithMultipartBodyType(baseUrl, payload, headers));
        Response response = requestSpecification.when().post(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPostWithMultiPartMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers, Map<String, Object> query) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecificationWithMultipartBodyType(baseUrl, payload, headers, query));
        Response response = requestSpecification.when().post(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPostWithMultiPartMethod(String baseUrl, String endpoint, Object payload) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecificationWithMultipartBodyType(baseUrl, payload));
        Response response = requestSpecification.when().post(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }


    public Response performPutWithMultiPartMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecificationWithMultipartBodyType(baseUrl, payload, headers));
        Response response = requestSpecification.when().put(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPutWithMultiPartMethod(String baseUrl, String endpoint, Object payload, Map<String, String> headers, Map<String, Object> query) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecificationWithMultipartBodyType(baseUrl, payload, headers, query));
        Response response = requestSpecification.when().put(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

    public Response performPutWithMultiPartMethod(String baseUrl, String endpoint, Object payload) {
        RequestSpecification requestSpecification = given().spec(SpecBuilder.getRequestSpecificationWithMultipartBodyType(baseUrl, payload));
        Response response = requestSpecification.when().put(endpoint);
        printRequestLogInReportWithPayload(requestSpecification);
        return response;
    }

}
