package com.swirl.base;

public class EndPoints {

    public static final String CASES = "api/users";


}
