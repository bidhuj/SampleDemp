package com.swirl.base;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.swirl.base.CreateUserPayload;;

public class BuildAPayload {

    public CreateUserPayload buildCreateUserPayload(String name, String job) {
        return CreateUserPayload.builder().name(name).job(job).build();
       
    }
    
    public String generateStringFromResource(String path) throws IOException {

        return new String(Files.readAllBytes(Paths.get(path)));

    }
}
