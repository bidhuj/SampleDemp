package com.swirl.base;


public class ObjectManager extends APIMethod {

    public BuildAPayload buildAPayload = new BuildAPayload();
}
