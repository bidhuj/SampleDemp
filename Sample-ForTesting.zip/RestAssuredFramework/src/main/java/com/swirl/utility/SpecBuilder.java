package com.swirl.utility;


import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;

import java.io.File;
import java.util.Map;

import com.swirl.base.Log;

public class SpecBuilder {

    private SpecBuilder() {

    }


    public static RequestSpecification getRequestSpecification(String baseUrl, Object requestPayload, Map<String, String> headers) {

        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)
                .addHeaders(headers)
                .setContentType(ContentType.JSON)
                .setBody(requestPayload).log(LogDetail.ALL).build();
    }

    public static RequestSpecification getRequestSpecification(String baseUrl, Object requestPayload,
                                                               Map<String, String> headers,
                                                               Map<String, Object> queryParameter) {
        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)
                .addHeaders(headers)
                .addQueryParams(queryParameter)
                .setContentType(ContentType.JSON)
                .setBody(requestPayload).log(LogDetail.ALL).build();

    }

    public static RequestSpecification getRequestSpecification(String baseUrl, Object requestPayload
    ) {
        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)
                .setContentType(ContentType.JSON)
                .setBody(requestPayload).log(LogDetail.ALL).build();
    }

    public static RequestSpecification getRequestSpecification(String baseUrl,
                                                               Map<String, String> headers,
                                                               Map<String, String> queryParameter) {
        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)
                .addHeaders(headers)
                .addQueryParams(queryParameter)
                .setContentType(ContentType.JSON).log(LogDetail.ALL)
                .build();
    }

    public static RequestSpecification getRequestSpecification(String baseUrl,
                                                               Map<String, String> queryParameter) {
        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)
                .addQueryParams(queryParameter)
                .setContentType(ContentType.JSON).log(LogDetail.ALL)
                .build();
    }

    public static RequestSpecification getRequestSpecificationWithMultipartBodyType(String baseUrl, Object filePath,
                                                                                    Map<String, String> headers) {

        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)

                .addHeaders(headers)
                .setContentType(ContentType.JSON)
                .addMultiPart(new File((String) filePath)).log(LogDetail.ALL).build();
    }

    public static RequestSpecification getRequestSpecificationWithMultipartBodyType(String baseUrl, Object filePath,
                                                                                    Map<String, String> headers,
                                                                                    Map<String, Object> queryParameter) {

        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)
                .addHeaders(headers)
                .addQueryParams(queryParameter)
                .setContentType(ContentType.JSON).log(LogDetail.ALL)
                .addMultiPart(new File((String) filePath)).build();
    }

    public static RequestSpecification getRequestSpecificationWithMultipartBodyType(String baseUrl, Object filePath
    ) {
        return new RequestSpecBuilder()
                .setBaseUri(baseUrl)
                .setContentType(ContentType.JSON)
                .addMultiPart(new File((String) filePath)).log(LogDetail.ALL).build();
    }


    public static void printRequestLogInReport(RequestSpecification requestSpecification) {
        QueryableRequestSpecification queryableRequestSpecification = SpecificationQuerier.query(requestSpecification);
        Log.info("baseUrl is " + queryableRequestSpecification.getBaseUri());
        Log.info("Method is " + queryableRequestSpecification.getMethod());
        Log.info("endpoint : " + queryableRequestSpecification.getUserDefinedPath());
        Log.info("Headers are ");
        Log.info(queryableRequestSpecification.getHeaders().asList().toString());
        Log.info("Request body is ");
//        Log.info(queryableRequestSpecification.getBody());
        Log.info(queryableRequestSpecification.getQueryParams().toString());
    }

    public static void printRequestLogInReportWithPayload(RequestSpecification requestSpecification) {
        QueryableRequestSpecification queryableRequestSpecification = SpecificationQuerier.query(requestSpecification);
        Log.info("baseUrl is " + queryableRequestSpecification.getBaseUri());
        Log.info("Method is " + queryableRequestSpecification.getMethod());
        Log.info("endpoint : " + queryableRequestSpecification.getUserDefinedPath());
        Log.info("Headers are ");
        Log.info(queryableRequestSpecification.getHeaders().asList().toString());
        Log.info("Request body is ");
        Log.info(queryableRequestSpecification.getBody());
        Log.info(queryableRequestSpecification.getQueryParams().toString());
    }

    public static void printResponseLogInReport(Response response) {
        Log.info("Response status is " + response.getStatusCode());
        Log.info("Response Headers are ");
        Log.info(response.getHeaders().asList().toString());
        Log.info("Response body is ");
        Log.info(response.getBody().prettyPrint());
    }
}
