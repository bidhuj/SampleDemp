package com.swirl.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties {

    public Properties initProperties(String path) {

        Properties prop = new Properties();
        File file = new File(path);
        try(FileInputStream fis = new FileInputStream(file)) {
            if (!file.exists()) {
                throw new FileNotFoundException("File doesn't exits");
            }
            prop.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return prop;
    }
}
