package com.swirl.utility;

import java.sql.*;
import java.util.Properties;

public class MySqlDBConnection {

    private Connection connection;
    private   Statement statement;
    private void databaseSetup() {
        try {
            //created a database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            //get connection to database
            connection = DriverManager.getConnection("", "",
                    "");
            //statement object is created to send request to database
            statement = connection.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet retrieveData(String sqlQuery) {
        databaseSetup();
        ResultSet resultSet;
        try {
            resultSet = statement.executeQuery(sqlQuery);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            databaseTearDown();
        }
        return resultSet;
    }

        private void databaseTearDown() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
}
