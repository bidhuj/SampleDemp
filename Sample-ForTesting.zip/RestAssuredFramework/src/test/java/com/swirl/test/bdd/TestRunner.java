package com.swirl.test.bdd;

import static com.swirl.base.Hooks.*;


import com.swirl.utility.JsonUtility;
import com.swirl.report.CucumberExtentReports;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;


@CucumberOptions(features = {"com.swirl.bdd.features"},
        plugin = { "pretty", "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
                "json:target/MyReports/cucumber.json", "testng:target/MyReports/report.xml",
        "html:target/cucumber-html-report.html","rerun:target/failedRerun.txt"},
        tags = "@Demo",
        monochrome = true,
//        dryRun = false,

        glue = {"com.swirl.bdd.stepsdefinition","com.swirl.base.hooks"})
public class TestRunner extends AbstractTestNGCucumberTests {



    @AfterSuite
    public void afterSuite() {
//        CucumberExtentReports reports = new CucumberExtentReports();
  //      CucumberExtentReports.cucumberReports("reports");
//        String filePath = EmailUtil.prop.getProperty("ReportPath");
//        String fileName = EmailUtil.prop.getProperty("FileName");
//        EmailUtil.sendMail(filePath, fileName);
    }

////    @Override
////    @DataProvider(parallel = true)
////    public Object[][] scenarios() {
////        return super.scenarios();
////    }
}
